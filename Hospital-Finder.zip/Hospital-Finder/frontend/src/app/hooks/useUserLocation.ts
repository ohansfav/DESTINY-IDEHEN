import { useEffect, useState } from 'react';

const FALLBACK_LOCATION = { lat: -1.286389, lng: 36.817223 }; // Set Nairobi as the fallback location

const getIpFallbackLocation = async () => {
  try {
    const response = await fetch('https://ipapi.co/json/');
    if (!response.ok) {
      throw new Error('IP lookup failed');
    }

    const data = await response.json();
    if (typeof data.latitude === 'number' && typeof data.longitude === 'number') {
      return { lat: data.latitude, lng: data.longitude };
    }
  } catch (error) {
    console.warn('IP-based fallback location failed, using Nairobi fallback.', error);
  }

  return FALLBACK_LOCATION;
};

export const useUserLocation = (
  overrideLocation?: { lat: number; lng: number } | null
) => {
  const [location, setLocation] = useState<{ lat: number; lng: number } | null>(
    null
  );

  useEffect(() => {
    let cancelled = false;

    if (overrideLocation) {
      setLocation(overrideLocation);
      return () => {
        cancelled = true;
      };
    }

    if (!navigator.geolocation) {
      console.warn('Geolocation not supported, using IP fallback location.');
      getIpFallbackLocation().then((fallbackLocation) => {
        if (!cancelled) {
          setLocation(fallbackLocation);
        }
      });
      return () => {
        cancelled = true;
      };
    }

    let hasLivePosition = false;

    const onSuccess = (pos: GeolocationPosition) => {
      hasLivePosition = true;
      setLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude });
    };

    const onError = (err: GeolocationPositionError) => {
      if (!hasLivePosition) {
        console.warn('Could not get live location, using IP fallback location.', err);
        getIpFallbackLocation().then((fallbackLocation) => {
          if (!cancelled && !hasLivePosition) {
            setLocation(fallbackLocation);
          }
        });
      }
    };

    navigator.geolocation.getCurrentPosition(onSuccess, onError, {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 30000,
    });

    const watchId = navigator.geolocation.watchPosition(onSuccess, onError, {
      enableHighAccuracy: true,
      timeout: 10000,
      maximumAge: 5000,
    });

    return () => {
      cancelled = true;
      navigator.geolocation.clearWatch(watchId);
    };
  }, [overrideLocation]);

  return location;
};