// /app/api/places/route.ts
import { NextRequest, NextResponse } from 'next/server';

function createSeed(lat: number, lng: number) {
	const latSeed = Math.floor((lat + 90) * 100000);
	const lngSeed = Math.floor((lng + 180) * 100000);
	return (latSeed * 73856093) ^ (lngSeed * 19349663);
}

function mulberry32(seed: number) {
	let t = seed >>> 0;
	return () => {
		t += 0x6d2b79f5;
		let r = Math.imul(t ^ (t >>> 15), 1 | t);
		r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
		return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
	};
}

function computeOffset(lat: number, distanceKm: number, angleRad: number) {
	const latDelta = (distanceKm / 111) * Math.cos(angleRad);
	const lngDelta =
		(distanceKm / Math.max(111 * Math.cos((lat * Math.PI) / 180), 0.01)) *
		Math.sin(angleRad);

	return { dLat: latDelta, dLng: lngDelta };
}

function buildHospitalName(rand: () => number) {
	const nameA = [
		'Central',
		'City',
		'Metro',
		'St. Mary',
		'Mercy',
		'Hope',
		'Unity',
		'General',
		'Westside',
		'Riverside',
	] as const;
	const nameB = [
		'Medical Center',
		'Hospital',
		'Emergency Clinic',
		'Health Institute',
		'Trauma Center',
		'Care Hospital',
	] as const;

	const left = nameA[Math.floor(rand() * nameA.length)];
	const right = nameB[Math.floor(rand() * nameB.length)];
	return `${left} ${right}`;
}

function generateFallbackHospitals(lat: number, lng: number) {
	const seed = createSeed(lat, lng);
	const rand = mulberry32(seed);

	const count = 10;
	const generated = [];

	for (let index = 0; index < count; index += 1) {
		const distance = 0.8 + rand() * 6.5;
		const angle = rand() * Math.PI * 2;
		const offset = computeOffset(lat, distance, angle);

		generated.push({
			name: buildHospitalName(rand),
			geometry: {
				location: {
					lat: lat + offset.dLat,
					lng: lng + offset.dLng,
				},
			},
			vicinity: `Approx. ${distance.toFixed(1)} km from your location`,
			rating: Number((3.3 + rand() * 1.7).toFixed(1)),
			opening_hours: {
				open_now: rand() > 0.35,
			},
			place_id: `fallback-${seed}-${index + 1}`,
		});
	}

	return generated;
}

export async function GET(req: NextRequest) {
	const { searchParams } = new URL(req.url);
	const lat = searchParams.get('lat');
	const lng = searchParams.get('lng');

	if (!lat || !lng) {
		return NextResponse.json({ error: 'Missing coordinates' }, { status: 400 });
	}

	const numericLat = Number(lat);
	const numericLng = Number(lng);

	if (Number.isNaN(numericLat) || Number.isNaN(numericLng)) {
		return NextResponse.json({ error: 'Invalid coordinates' }, { status: 400 });
	}

	const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;
	const radius = 5000; // meters
	if (!apiKey) {
		return NextResponse.json({
			results: generateFallbackHospitals(numericLat, numericLng),
			fallback: true,
		});
	}

	const url = `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${numericLat},${numericLng}&radius=${radius}&type=hospital&key=${apiKey}`;

	try {
		const res = await fetch(url);
		const data = await res.json();

		if (
			data?.status &&
			data.status !== 'OK' &&
			data.status !== 'ZERO_RESULTS'
		) {
			return NextResponse.json({
				results: generateFallbackHospitals(numericLat, numericLng),
				fallback: true,
				error: data?.error_message ?? 'Google Places request failed',
			});
		}

		return NextResponse.json(data);
	} catch (error) {
		console.error('Google API Error:', error);
		return NextResponse.json({
			results: generateFallbackHospitals(numericLat, numericLng),
			fallback: true,
		});
	}
}
