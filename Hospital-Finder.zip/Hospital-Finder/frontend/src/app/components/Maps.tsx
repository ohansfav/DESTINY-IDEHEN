﻿'use client';

import React, { useEffect, useMemo, useState } from 'react';
import dynamic from 'next/dynamic';
import Container from './common/Container';
import Title from './common/Title';
import { HospitalCard } from './HospitalCard';
import { useUserLocation } from '../hooks/useUserLocation';
import { useHospitalData } from '../hooks/useHospitalData';

type MapsProps = {
overrideLocation?: { lat: number; lng: number } | null;
};

const LeafletMapViewClient = dynamic(
	() => import('./LeafletMapViewClient').then((mod) => mod.default),
	{
		ssr: false,
		loading: () => (
			<div className="h-[400px] flex items-center justify-center bg-gray-50 text-gray-600 text-sm">
				Loading map...
			</div>
		),
	}
);

const getHospitalId = (hospital: {
placeId?: string;
name: string;
lat: number;
lng: number;
}) => hospital.placeId || `${hospital.name}-${hospital.lat}-${hospital.lng}`;

const distanceKm = (
from: { lat: number; lng: number },
to: { lat: number; lng: number }
) => {
const toRad = (deg: number) => (deg * Math.PI) / 180;
const earthRadiusKm = 6371;
const dLat = toRad(to.lat - from.lat);
const dLng = toRad(to.lng - from.lng);
const a =
Math.sin(dLat / 2) ** 2 +
Math.cos(toRad(from.lat)) *
Math.cos(toRad(to.lat)) *
Math.sin(dLng / 2) ** 2;
return 2 * earthRadiusKm * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
};

const Maps: React.FC<MapsProps> = ({ overrideLocation }) => {
const location = useUserLocation(overrideLocation);
const hospitals = useHospitalData(location);
const [selectedHospitalId, setSelectedHospitalId] = useState<string | null>(null);
const [traceProgress, setTraceProgress] = useState(0);
const [routeCoords, setRouteCoords] = useState<[number, number][]>([]);
const [routeLoading, setRouteLoading] = useState(false);

const sortedHospitals = useMemo(() => {
if (!location) return hospitals;
return [...hospitals].sort((a, b) => {
const distA = distanceKm(location, { lat: a.lat, lng: a.lng });
const distB = distanceKm(location, { lat: b.lat, lng: b.lng });
return distA - distB;
});
}, [hospitals, location]);

useEffect(() => {
if (!selectedHospitalId) return;
const exists = sortedHospitals.some((h) => getHospitalId(h) === selectedHospitalId);
if (!exists) setSelectedHospitalId(null);
}, [selectedHospitalId, sortedHospitals]);

const selectedHospital = useMemo(
() => sortedHospitals.find((h) => getHospitalId(h) === selectedHospitalId) ?? null,
[selectedHospitalId, sortedHospitals]
);

useEffect(() => {
if (!selectedHospital || !location) { setRouteCoords([]); return; }
let cancelled = false;
setRouteLoading(true);
setRouteCoords([]);
const url =
`https://router.project-osrm.org/route/v1/driving/` +
`${location.lng},${location.lat};${selectedHospital.lng},${selectedHospital.lat}` +
`?overview=full&geometries=geojson`;
fetch(url)
.then((r) => r.json())
.then((data) => {
if (cancelled) return;
const coords = data?.routes?.[0]?.geometry?.coordinates;
if (Array.isArray(coords) && coords.length > 0) {
setRouteCoords(coords.map(([lng, lat]: [number, number]) => [lat, lng]));
} else {
setRouteCoords([[location.lat, location.lng], [selectedHospital.lat, selectedHospital.lng]]);
}
})
.catch(() => {
if (!cancelled) setRouteCoords([[location.lat, location.lng], [selectedHospital.lat, selectedHospital.lng]]);
})
.finally(() => { if (!cancelled) setRouteLoading(false); });
return () => { cancelled = true; };
}, [selectedHospital, location]);

useEffect(() => {
if (!selectedHospital || routeCoords.length === 0) { setTraceProgress(0); return; }
setTraceProgress(0);
const timer = window.setInterval(() => {
setTraceProgress((prev) => (prev >= 1 ? 0 : prev + 0.008));
}, 30);
return () => window.clearInterval(timer);
}, [selectedHospital, routeCoords]);

if (!location) {
return (
<div className="flex items-center justify-center h-[300px] w-full">
<div className="flex flex-col items-center space-y-4">
<div className="h-12 w-12 animate-spin rounded-full border-4 border-green border-t-transparent" />
<p className="text-gray-600 font-medium">Getting your location...</p>
</div>
</div>
);
}

	const directDistance = selectedHospital
		? distanceKm(location, { lat: selectedHospital.lat, lng: selectedHospital.lng })
		: null;

	return (
		<section id="find-hospital">
			<Container className="py-5 md:py-10">
				<Title
					title="Nearby Hospitals"
					description="Real map view using your current location. Click any hospital to trace your route."
				/>
				<div className="flex flex-col md:flex-row gap-5 my-8">
					<div className="w-full md:w-3/4">
						<div className="rounded-2xl border border-gray-200 bg-white shadow-sm overflow-hidden">
							<div className="flex items-center justify-between bg-emerald-50 border-b border-emerald-100 px-4 py-3">
								<p className="text-sm font-medium text-emerald-900">
									Your position: {location.lat.toFixed(5)}, {location.lng.toFixed(5)}
								</p>
								{selectedHospital && directDistance !== null && (
									<p className="text-xs text-emerald-800">
										Route to {selectedHospital.name}: {directDistance.toFixed(2)} km
									</p>
								)}
							</div>
							<LeafletMapViewClient
								location={location}
								hospitals={sortedHospitals}
								selectedHospitalId={selectedHospitalId}
								traceProgress={traceProgress}
								routeCoords={routeCoords}
								routeLoading={routeLoading}
								onSelectHospital={setSelectedHospitalId}
								getHospitalId={getHospitalId}
							/>
						</div>
					</div>
					<div className="w-full md:w-1/4 mt-4 md:mt-0 flex flex-col gap-2 max-h-[640px] overflow-y-auto">
						{sortedHospitals.length === 0 && (
							<p className="text-sm text-gray-500">No hospitals found nearby.</p>
						)}
						{sortedHospitals.map((hospital) => {
							const hospitalId = getHospitalId(hospital);
							const isSelected = selectedHospitalId === hospitalId;
							const hospitalDistance = distanceKm(location, { lat: hospital.lat, lng: hospital.lng });
							return (
								<div
									key={hospitalId}
									onClick={() => setSelectedHospitalId(hospitalId)}
									style={{ cursor: 'pointer' }}
								>
									<HospitalCard hospital={hospital} selected={isSelected} />
									<p className="-mt-1 mb-2 text-xs text-gray-600">
										Approx. {hospitalDistance.toFixed(2)} km away
									</p>
									<button
										type="button"
										className="mt-2 w-full rounded-lg bg-green px-3 py-2 text-white text-sm font-semibold hover:bg-green-800"
										onClick={(e) => {
											e.stopPropagation();
											setSelectedHospitalId(hospitalId);
										}}
									>
										Trace Route
									</button>
								</div>
							);
						})}
					</div>
				</div>
			</Container>
		</section>
	);
};

export default Maps;