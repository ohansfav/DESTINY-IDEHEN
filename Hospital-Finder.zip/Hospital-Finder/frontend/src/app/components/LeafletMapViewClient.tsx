'use client';

import React, { useEffect, useMemo, useRef } from 'react';
import {
	GoogleMap,
	MarkerF,
	InfoWindowF,
	PolylineF,
	useJsApiLoader,
} from '@react-google-maps/api';
import type { Hospital } from './HospitalCard';

export type LeafletMapViewProps = {
	location: { lat: number; lng: number };
	hospitals: Hospital[];
	selectedHospitalId: string | null;
	traceProgress: number;
	routeCoords: [number, number][];
	routeLoading: boolean;
	onSelectHospital: (id: string) => void;
	getHospitalId: (hospital: Hospital) => string;
};

const mapContainerStyle = { width: '100%', height: '400px' };

const googleLibraries: ('places')[] = ['places'];

function interpolatePolyline(coords: [number, number][], t: number): [number, number] {
	if (coords.length === 0) return [0, 0];
	if (coords.length === 1) return coords[0];
	if (t <= 0) return coords[0];
	if (t >= 1) return coords[coords.length - 1];

	const segLengths: number[] = [];
	let total = 0;
	for (let i = 1; i < coords.length; i++) {
		const d = Math.hypot(coords[i][0] - coords[i - 1][0], coords[i][1] - coords[i - 1][1]);
		segLengths.push(d);
		total += d;
	}

	let remaining = t * total;
	for (let i = 0; i < segLengths.length; i++) {
		if (remaining <= segLengths[i]) {
			const frac = segLengths[i] === 0 ? 0 : remaining / segLengths[i];
			return [
				coords[i][0] + (coords[i + 1][0] - coords[i][0]) * frac,
				coords[i][1] + (coords[i + 1][1] - coords[i][1]) * frac,
			];
		}
		remaining -= segLengths[i];
	}

	return coords[coords.length - 1];
}

export default function LeafletMapViewClient(props: LeafletMapViewProps) {
	const mapRef = useRef<google.maps.Map | null>(null);
	const [activeHospitalId, setActiveHospitalId] = React.useState<string | null>(null);
	const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || '';
	const { isLoaded, loadError } = useJsApiLoader({
		googleMapsApiKey: apiKey,
		libraries: googleLibraries,
	});

	useEffect(() => {
		if (!mapRef.current) {
			return;
		}

		mapRef.current.panTo(props.location);
	}, [props.location]);

	const traceDotPos: [number, number] | null =
		props.routeCoords.length >= 2
			? interpolatePolyline(props.routeCoords, props.traceProgress)
			: null;

	const routePath = useMemo(
		() => props.routeCoords.map(([lat, lng]) => ({ lat, lng })),
		[props.routeCoords]
	);

	if (!apiKey) {
		return (
			<div className="h-[400px] flex items-center justify-center bg-gray-50 text-gray-600 text-sm px-4 text-center">
				Google Maps API key is missing. Set NEXT_PUBLIC_GOOGLE_MAPS_API_KEY to load the Google map.
			</div>
		);
	}

	if (loadError) {
		return (
			<div className="h-[400px] flex items-center justify-center bg-gray-50 text-red-600 text-sm px-4 text-center">
				Failed to load Google Maps.
			</div>
		);
	}

	if (!isLoaded) {
		return (
			<div className="h-[400px] flex items-center justify-center bg-gray-50 text-gray-600 text-sm">
				Loading map...
			</div>
		);
	}

	return (
		<div style={{ position: 'relative' }}>
			{props.routeLoading && (
				<div
					style={{
						position: 'absolute',
						top: 8,
						left: '50%',
						transform: 'translateX(-50%)',
						zIndex: 1000,
						background: 'rgba(255,255,255,0.92)',
						borderRadius: 20,
						padding: '4px 14px',
						fontSize: 12,
						color: '#374151',
						boxShadow: '0 1px 4px rgba(0,0,0,0.15)',
						pointerEvents: 'none',
					}}
				>
					Finding route…
				</div>
			)}

			<GoogleMap
				mapContainerStyle={mapContainerStyle}
				center={props.location}
				zoom={14}
				onLoad={(map) => {
					mapRef.current = map;
				}}
				options={{
					streetViewControl: false,
					mapTypeControl: false,
					fullscreenControl: false,
				}}
			>
				<MarkerF
					position={props.location}
					icon={{
						path: google.maps.SymbolPath.CIRCLE,
						scale: 9,
						fillColor: '#10b981',
						fillOpacity: 1,
						strokeColor: '#ffffff',
						strokeWeight: 3,
					}}
				/>

				{props.hospitals.map((hospital) => {
					const hospitalId = props.getHospitalId(hospital);
					const isSelected = hospitalId === props.selectedHospitalId;
					return (
						<MarkerF
							key={hospitalId}
							position={{ lat: hospital.lat, lng: hospital.lng }}
							onClick={() => {
								props.onSelectHospital(hospitalId);
								setActiveHospitalId(hospitalId);
							}}
							icon={{
								path: google.maps.SymbolPath.CIRCLE,
								scale: 8,
								fillColor: isSelected ? '#1a73e8' : '#ef4444',
								fillOpacity: 1,
								strokeColor: '#ffffff',
								strokeWeight: 2,
							}}
						>
							{activeHospitalId === hospitalId && (
								<InfoWindowF onCloseClick={() => setActiveHospitalId(null)}>
									<div>
										<strong>{hospital.name}</strong>
										{hospital.vicinity && <p style={{ marginTop: 4 }}>{hospital.vicinity}</p>}
									</div>
								</InfoWindowF>
							)}
						</MarkerF>
					);
				})}

				{routePath.length >= 2 && (
					<>
						<PolylineF
							path={routePath}
							options={{ strokeColor: '#ffffff', strokeOpacity: 0.6, strokeWeight: 9 }}
						/>
						<PolylineF
							path={routePath}
							options={{ strokeColor: '#1a73e8', strokeOpacity: 1, strokeWeight: 5 }}
						/>
					</>
				)}

				{traceDotPos && (
					<MarkerF
						position={{ lat: traceDotPos[0], lng: traceDotPos[1] }}
						icon={{
							path: google.maps.SymbolPath.CIRCLE,
							scale: 8,
							fillColor: '#ffffff',
							fillOpacity: 1,
							strokeColor: '#1a73e8',
							strokeWeight: 3,
						}}
					/>
				)}
			</GoogleMap>
		</div>
	);
}
