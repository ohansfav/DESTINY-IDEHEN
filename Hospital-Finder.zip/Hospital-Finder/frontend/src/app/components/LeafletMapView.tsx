// @ts-nocheck  — leaflet has no bundled .d.ts; suppress missing-type errors (runtime is correct).
'use client';

import React from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup, Polyline } from 'react-leaflet';
import type { Hospital } from './HospitalCard';

/**
 * Walk along a polyline and return the [lat, lng] position at fraction t (0–1)
 * of the total arc length. Works with any number of segments.
 */
function interpolatePolyline(coords: [number, number][], t: number): [number, number] {
	if (coords.length === 0) return [0, 0];
	if (coords.length === 1) return coords[0];
	if (t <= 0) return coords[0];
	if (t >= 1) return coords[coords.length - 1];

	// Compute cumulative Euclidean distances in lat/lng space (good enough for short routes)
	const segLengths: number[] = [];
	let total = 0;
	for (let i = 1; i < coords.length; i++) {
		const d = Math.hypot(coords[i][0] - coords[i - 1][0], coords[i][1] - coords[i - 1][1]);
		segLengths.push(d);
		total += d;
	}

	let remaining = t * total;
	for (let i = 0; i < segLengths.length; i++) {
		if (remaining <= segLengths[i]) {
			const frac = segLengths[i] === 0 ? 0 : remaining / segLengths[i];
			return [
				coords[i][0] + (coords[i + 1][0] - coords[i][0]) * frac,
				coords[i][1] + (coords[i + 1][1] - coords[i][1]) * frac,
			];
		}
		remaining -= segLengths[i];
	}
	return coords[coords.length - 1];
}

interface LeafletMapViewProps {
	location: { lat: number; lng: number };
	hospitals: Hospital[];
	selectedHospitalId: string | null;
	traceProgress: number;
	routeCoords: [number, number][];
	routeLoading: boolean;
	onSelectHospital: (id: string) => void;
	getHospitalId: (h: Hospital) => string;
}

const LeafletMapView: React.FC<LeafletMapViewProps> = ({
	location,
	hospitals,
	selectedHospitalId,
	traceProgress,
	routeCoords,
	routeLoading,
	onSelectHospital,
	getHospitalId,
}) => {
	const traceDotPos: [number, number] | null =
		routeCoords.length >= 2
			? interpolatePolyline(routeCoords, traceProgress)
			: null;

	return (
		<div style={{ position: 'relative' }}>
			{/* Loading overlay while fetching OSRM route */}
			{routeLoading && (
				<div
					style={{
						position: 'absolute',
						top: 8,
						left: '50%',
						transform: 'translateX(-50%)',
						zIndex: 1000,
						background: 'rgba(255,255,255,0.92)',
						borderRadius: 20,
						padding: '4px 14px',
						fontSize: 12,
						color: '#374151',
						boxShadow: '0 1px 4px rgba(0,0,0,0.15)',
						pointerEvents: 'none',
					}}
				>
					Finding route…
				</div>
			)}

			<MapContainer
				center={[location.lat, location.lng]}
				zoom={14}
				style={{ width: '100%', height: '400px' }}
				scrollWheelZoom={true}
			>
				<TileLayer
					attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
					url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
				/>

				{/* User location — green dot with white ring */}
				<CircleMarker
					center={[location.lat, location.lng]}
					radius={10}
					pathOptions={{ fillColor: '#10b981', fillOpacity: 1, color: '#ffffff', weight: 3 }}
				>
					<Popup>You are here</Popup>
				</CircleMarker>

				{/* Hospital markers */}
				{hospitals.map((hospital) => {
					const hospitalId = getHospitalId(hospital);
					const isSelected = hospitalId === selectedHospitalId;
					return (
						<CircleMarker
							key={hospitalId}
							center={[hospital.lat, hospital.lng]}
							radius={8}
							pathOptions={{
								fillColor: isSelected ? '#1a73e8' : '#ef4444',
								fillOpacity: 1,
								color: '#ffffff',
								weight: 2,
							}}
							eventHandlers={{ click: () => onSelectHospital(hospitalId) }}
						>
							<Popup>
								<strong>{hospital.name}</strong>
								{hospital.vicinity && (
									<p style={{ fontSize: '0.75rem', color: '#4b5563', marginTop: '0.25rem' }}>
										{hospital.vicinity}
									</p>
								)}
							</Popup>
						</CircleMarker>
					);
				})}

				{/* Real road route — blue like Google Maps */}
				{routeCoords.length >= 2 && (
					<>
						{/* White outline for contrast */}
						<Polyline
							positions={routeCoords}
							pathOptions={{ color: '#ffffff', weight: 9, opacity: 0.6 }}
						/>
						{/* Blue route line */}
						<Polyline
							positions={routeCoords}
							pathOptions={{ color: '#1a73e8', weight: 5, opacity: 1 }}
						/>
					</>
				)}

				{/* Animated trace dot — rides along the real road path */}
				{traceDotPos && (
					<CircleMarker
						center={traceDotPos}
						radius={8}
						pathOptions={{ fillColor: '#ffffff', fillOpacity: 1, color: '#1a73e8', weight: 3 }}
					/>
				)}
			</MapContainer>
		</div>
	);
};

export default LeafletMapView;

